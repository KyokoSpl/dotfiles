local cmp = require "cmp"

local plugins = {

  {
    "williamboman/mason.nvim",
    opts = {
      ensure_installed = {
        "rust-analyzer",
        "clangd",
        "clang-format",
        "codelldb",
        "stylua",
        "vue-language-server",
        "vscode-eslint-language-server",
        "typescript-language-server",
      },
    },
  },
--  {
--     "github/copilot.vim", 
    
--     lazy = false,
--     config = function()
--       -- Mapping tab is already used by NvChad
--       vim.g.copilot_no_tab_map = true;
--       vim.g.copilot_assume_mapped = true;
--       vim.g.copilot_tab_fallback = "";
--       -- The mapping is set to other key, see custom/lua/mappings
--       -- or run <leader>ch to see copilot mapping section
--     end
--   },

  {
    "neovim/nvim-lspconfig",
    config = function()
      require "plugins.configs.lspconfig"
      require "custom.configs.lspconfig"
    end,
  },
  -- Add vue and eslint language servers
  {
    "jose-elias-alvarez/typescript.nvim",
    ft = { "typescript", "typescriptreact", "javascript", "javascriptreact" },
    dependencies = "neovim/nvim-lspconfig",
  },
  {
    "mrcjkb/rustaceanvim",
    version = "^4",
    ft = { "rust" },
    dependencies = "neovim/nvim-lspconfig",
    config = function()
      require "custom.configs.rustaceanvim"
    end
  },
  {
    "mfussenegger/nvim-dap",
    init = function()
      require("core.utils").load_mappings("dap")
    end
  },
  {
    'saecki/crates.nvim',
    ft = {"toml"},
    config = function(_, opts)
      local crates  = require('crates')
      crates.setup(opts)
      require('cmp').setup.buffer({
        sources = { { name = "crates" }}
      })
      crates.show()
      require("core.utils").load_mappings("crates")
    end,
  },
  {
    "rust-lang/rust.vim",
    ft = "rust",
    init = function ()
      vim.g.rustfmt_autosave = 1
    end
  },
  {
    "theHamsta/nvim-dap-virtual-text",
    lazy = false,
    config = function(_, opts)
      require("nvim-dap-virtual-text").setup()
    end
  },
  {
    "hrsh7th/nvim-cmp",
    opts = function()
      local M = require "plugins.configs.cmp"
      M.completion.completeopt = "menu,menuone,noselect"
      M.mapping["<CR>"] = cmp.mapping.confirm {
        behavior = cmp.ConfirmBehavior.Insert,
        select = false,
      }
      table.insert(M.sources, {name = "crates"})
      return M
    end,
  },
  {
    "simrat39/rust-tools.nvim",
    ft = { "rust" },
    dependencies = "neovim/nvim-lspconfig", -- Fixed: depencencies -> dependencies
    opts = function()
      return require("custom.configs.rust-tools") -- Fixed: added return
    end,
    config = function(_, opts)
      require("rust-tools").setup(opts)
    end,
  },
  {
  "CopilotC-Nvim/CopilotChat.nvim",
  branch = "canary",
  dependencies = {
    { "zbirenbaum/copilot.lua" },
    { "nvim-lua/plenary.nvim" },
  },
  config = function()
    require("CopilotChat").setup({
      model = 'claude-3.5-sonnet', -- or 'claude-3.5-sonnet', 'gpt-4o-mini'
    })
  end,
},
{
  "zbirenbaum/copilot.lua",
  cmd = "Copilot",
  event = "InsertEnter",
  config = function()
    require("copilot").setup({
      copilot_model = 'claude-3.5-sonnet', -- or 'claude-3.5-sonnet', 'gpt-4o-mini'
      suggestion = {
        enabled = true,
        auto_trigger = true,
        debounce = 75,
        keymap = {
          accept = "<C-l>",
          accept_word = false,
          accept_line = false,
          next = "<M-]>",
          prev = "<M-[>",
          dismiss = "<C-]>",
        },
      },
      panel = { enabled = false },
      copilot_node_command = 'node', -- Node.js version must be > 16.x
      server_opts_overrides = {
        -- You can try different model settings here
        settings = {
          advanced = {
            listCount = 10, -- Number of completions
            inlineSuggestCount = 3, -- Number of inline suggestions
          }
        }
      },
    })
  end,
},
  {
    "nvim-treesitter/nvim-treesitter",
    opts = function(_, opts)
      local languages = {
        "lua", "luadoc", "printf", "vim", "vimdoc",
        "rust", "javascript", "typescript", "vue", "html", "css"
      }
      opts.ensure_installed = languages
      opts.highlight = {
        enable = true,
        use_languagetree = true,
      }
      opts.indent = { enable = true }
      return opts
    end,
  },
}
return plugins
